import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-password-specs',
  templateUrl: './password-specs.component.html',
  styleUrls: ['./password-specs.component.css']
})
export class PasswordSpecsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
